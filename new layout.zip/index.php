<html>
	<head>
		<title>Cibovagando</title>
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
		<meta name="keywords" content="cibo,vagando,cibovagando,food,shopper,personal,crearte, cooperativa, casale, casale monferrato, lavoro, offerte lavoro, eventi, piemonte, manifestazioni, organizzazione eventi, teatro, maschere, aiuto compiti, scuola, doposcuola, ripetizioni">
		<meta name="description" content="Cooperativa Crearte di Casale Monferrato, progetto Cibovagando">
		<link rel="stylesheet" type="text/css" media="screen" title="style" href="style.css" />
		<link rel="icon" type="image/png" href="immagini/lg.png" />
	</head>
	<body>
    	<div id="header" class="header">
			<div>
				<a href="index.php" ><img src="immagini/logoCV.png" width=13% class="headIMG"></a>
				<div class="mainTitle">
					<br/><h2><i>CIBOVAGANDO - Food&Wine Personal Shopper</i></h2>
					<h2><i>Esperienze Enogastronomiche di Qualit� - Taste Trails Planning</i></h2><br/><br/><br/><br/><br/>
				</div>
			</div>
			
			<div class="content">
				<ul id="horiznav" >
					<li class="list"><input type="button" class="menubuttons" onclick="document.location='aziende.php'" value="Servizi per le aziende"></input></li>
					<li class="list"><input type="button" class="menubuttons" onclick="document.location='privati.php'" value="Cibovagando per i privati"></input></li>
					<li class="list"><input type="button" class="menubuttons" onclick="document.location='turismo.php'" value="Cibovagando per il turismo"></input>
						<ul class="list">
							<li><input type="button" class="menubuttons" onclick="document.location='proposte_tematiche.php'" value="Proposte tematiche"></input></li>
							<li><input type="button" class="menubuttons" onclick="document.location='esp_personalizzate.php'" value="Esperienze personalizzate"></input></li>
							<!--<li><input type="button" class="menubuttons"  value="Prezzo del servizio"></input></li>-->
						</ul>
					</li>
					<li class="list"><input type="button" class="menubuttons" onclick="document.location='offerte.php'" value="Offerte speciali"></input></li>
				</ul>
			</div>
		</div>
		
		<div class="menu">
		<ul class="list" id="vertnav">
				<li><input type="button" class="menubuttons" onclick="document.location='index.php'" value="Home"></input></li>
				<li><input type="button" class="menubuttons" onclick="document.location='progetto.php'" value="Il progetto"></input></li>
				<li><input type="button" class="menubuttons" value="Food&Wine personal shopper"></input>
					<ul class="list">
						<li class="list"><input type="button" class="menubuttons" onclick="document.location='chi.php'" value="Chi �"></input></li>
						<li class="list"><input type="button" class="menubuttons" onclick="document.location='target.php'" value="A chi si rivolge"></input></li>
					</ul>
				</li>
				<li><input type="button" class="menubuttons"  value="Info"></input>
					<ul class="list">
						<li class="list"><input type="button" class="menubuttons" onclick="document.location='chi_siamo.php'" value="Chi siamo"></input></li>
						<li class="list"><input type="button" class="menubuttons" onclick="document.location='contatti.php'" value="Contatti"></input></li>
						<li class="list"><input type="button" class="menubuttons" onclick="document.location='faq.php'" value="FAQ"></input></li>
					</ul>
				</li>
			</ul>
			
		</div>
		
		<div id="contents" class="content">
			</br>
			<fieldset>
			<p>Cibovagando ti permette di scoprire i migliori prodotti enogastronomici del Monferrato! 
				Il nostro Food & Wine personal shopper vi guider� attraverso un vero e proprio percorso del 
				gusto tra la storiche vie di Casale Monferrato o per le splendide colline del Monferrato che 
				la circondano, per un'esperienza culinaria di qualit� tra i sapori della tradizione e la cucina pi� innovativa.  
				Il nostro Personal Shopper selezioner� per voi le migliori botteghe alimentari, produttori, 
				aziende agricole e ristoratori per farvi godere dei prodotti locali d'eccellenza, con il miglior 
				rapporto qualit� prezzo. Sapr� consigliarvi durante la scelta dei piatti pi� indicati ai vostri gusti, 
				darvi utili suggerimenti gastronomici per cucinare ci� che acquisterete, informazioni sugli 
				ingredienti e la storia dei piatti e dei prodotti tipici, consigli sul valore nutrizionale 
				degli alimenti e assistenza nell'acquisto del prodotto.
			</p>
			
			<img src="immagini/logoCV.png" alt="Logo" width=13%></img><p>Marchio disegnato da Anna Botteon per Soc. Coop. Crearte</p>
			<h2>
				<i>Come funziona?</i>
			</h2>
			<p>Il nostro personale qualificato vi accompagner� presso gli operatori alimentari selezionati 
				in base al percorso tematico scelto o in base alle vostre specifiche richieste, ad acquistare 
				i prodotti tipici del territorio, per un tempo da voi stabilito compreso tra due ore e un'intera giornata. 
				Attraverso la Cibovagando Card avrete diritto ad una serie di sconti su alcuni prodotti 
				precedentemente selezionati e ad un men� creato ad hoc per i nostri clienti.
			</p>
			<h2>
				<i>La Cibovagando Card</i>
			</h2>
			<p>Attraverso una convenzione con i migliori esercenti e produttori, siamo in grado di offrirvi 
				un'esclusiva scontistica sui prodotti tipici come muletta, crema di cioccolato e nocciole igp, 
				agnolotti, vini tipici del Monferrato Casalese, la monferrina di pasta dura e molti altri. 
				Vi consentir� inoltre di accedere ai men� appositamente ideati per Cibovagando, che vi permetteranno 
				di assaggiare i migliori piatti monferrini con un occhio speciale al prezzo su diverse fasce di budget. 
				Comprende, infine, una scontistica su alcuni prodotti non enogastronomici.
				La card � inclusa nel nostro servizio di Food & Wine Personal Shopper e riutilizzabile per due 
				volte nell'arco di un anno. Vi verr� consegnata dal F&W Personal Shopper e dovr� essere esibita 
				in caso di acquisto. 
			</p>
			</fieldset>
			<h4>
				<i>
					<a href="chi.php">Food and Wine Personal Shopper: Chi �?</a>
				</i>
			</h4>
		
		
		<iframe src="http://www.facebook.com/plugins/like.php?href=https://www.facebook.com/CibovagandoTasteTrail?fref=ts"
			scrolling="no" frameborder="0"
			style="border:none; width:70%; height:80px;"></iframe>
			<iframe src="http://www.facebook.com/plugins/like.php?href=YOUR_WEBPAGE"
			scrolling="no" frameborder="0"
			style="border:none; visibility:hidden;">
		</iframe>
		</div>
	</body>
	<footer><!--<p class="center">We speak: Italiano, English, Portugu�s, Fran�ais, Espanhol, Deutsch</p>-->
		<a href="https://www.linkedin.com/pub/matteo-patrucco/7b/562/989"><h6 class="center">License: (CC) 2014 Matteo Patrucco</h6></a>
	</footer>
</html>